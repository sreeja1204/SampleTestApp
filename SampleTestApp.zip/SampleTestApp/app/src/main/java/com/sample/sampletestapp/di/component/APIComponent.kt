package com.sample.sampletestapp.di.component

@Component(modules = APIModule::class)
interface PhotoAPIComponent {

    val photoAPI: PhotoAPI
    val userAPI: UsersAPI
}
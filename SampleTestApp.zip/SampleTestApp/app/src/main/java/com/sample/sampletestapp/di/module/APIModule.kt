package com.sample.sampletestapp.di.module

@Module
class PhotoAPIModule {

    val gsonConverterFactory: GsonConverterFactory
        @Provides
        get() = GsonConverterFactory.create()

    @Provides
    fun getPhotoAPI(retrofit: Retrofit): PhotoAPI {
        return retrofit.create(PhotoAPI::class.java)
    }

    @Provides
    fun getUserAPI(retrofit: Retrofit): UsersAPI {
        return retrofit.create(UsersAPI::class.java)
    }

    @Provides
    fun getRetrofit(gsonConverterFactory: GsonConverterFactory): Retrofit {
        return Retrofit.Builder()
            .baseUrl(APIConstants.BASE_URL)
            .addConverterFactory(gsonConverterFactory)
            .build()
    }
}
